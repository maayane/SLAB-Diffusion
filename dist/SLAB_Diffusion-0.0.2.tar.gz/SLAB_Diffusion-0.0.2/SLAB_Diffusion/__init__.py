__version__='0.0.2'
from .script import * #import all functions from the __all__ in script.py, the moment you do import catsHTM
